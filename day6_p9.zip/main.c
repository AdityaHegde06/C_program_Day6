/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*Check the grade of steel*/

#include <stdio.h>
#include<stdlib.h>
int main()
{
    float hard,carbon,tensile;
    
    printf("\n enter Hardness of the steel");
    scanf("%f",&hard);
    printf("\nEnter Carbon content:");
    scanf("%f",&carbon);
     printf("\nEnter tensile content");
    scanf("%f",&tensile);
    if(hard>50 && carbon < 0.7 && tensile > 5600 )
    {
        printf("Grade 10\n");
        exit(0);
    }
    if(hard>50 && carbon < 0.7 && tensile <= 5600 )
    {
        printf("Grade 9\n");
        exit(0);
    }   
    if(hard<=50 && carbon<0.7 && tensile>5600)
    {
      printf("Grade 8\n");
        exit(0);   
        }
        if(hard<=50 && carbon>=0.7 && tensile>5600)
    {
      printf("Grade 7\n"); 
      exit(0); 
    }
     if(hard<=50 ||carbon>=0.7 ||  tensile>5600)
    {
      printf("Grade 6\n");
      exit(0); 
    }
    printf("Grade 5\n");
    
    

    return 0;
}
