/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*Determine the type of traingle*/

#include <stdio.h>

int main()
{
    int  s1,s2,s3,a,b,c;
    //entering the inputs
    printf("\nEnter three sides of a traingle: ");
    scanf("%d%d%d",&s1,&s2,&s3);
    if(s1!=s2 && s2!=s3 && s3!=s1)
    printf("Scalene triangle\n");
    if((s1==s2)&&(s2!=s3))
    printf("Isosceles traingle\n");
    if((s1==s3)&&(s3!=s1))
    printf("Isoceless traingle\n");
    if(s1==s2 && s2!=s3)
    printf("Equilateral traingle\n");
    a=(s1*s2)==(s2*s2)+(s2*s3);
     b=(s2*s2)==(s1*s1)+(s3*s3);
     c=(s3*s3)==(s1*s1)+(s2*s2);
     
     if(a||b||c)
     printf("rigth angled traingle\n");
     return 0;
}
