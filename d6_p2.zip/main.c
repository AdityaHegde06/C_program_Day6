/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i=4,j=-1,k=0,w,x,y,z;
    w=i||j||k;
    printf("w=%d\n",w);
    x=i&&j&&k;
    printf("x=%d\n",x);
    y=i||j&&k;
    printf("y=%d\n",y);
    z=i&&j||k;
    printf("z=%d\n",z);
    printf("w=%d\n,x=%d\n,y=%d\n,z=%d\n",w,x,y,z);



    return 0;
}
