/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int i=4,z=12;
  printf("Enter the value of i and z");
  scanf("%d%d",&i,&z);
  if(i=5 || z>50)
  {
  printf("Dean of students affairs");
  }
  else
  {
      printf("Dosa\n");
      
  }
  

    return 0;
}
