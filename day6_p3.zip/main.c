/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x=20,y=40,z=45;
    if(x>y && x>z)
    {
    printf("biggest=%d\n",x);
    }
    else if(y>x&&y>z)
    {
    printf("Biggest=%d\n",y);
    }
    else if(z>x&&z>y)
    {
    printf("Biggest=%d\n",z);
    }

    return 0;
}
