/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

******************************************************************************/
/*colur Conversuion from RGB to Cmyk format*/
#include <stdio.h>

int main()
{
    float red,green,blue;
    float cyan,white,magneta,yellow,black;
    
    float max;
    printf("Enter Red,Green,Blue values(0 to 255) ");
    scanf("%f\n%f\n%f\n",&red,&green,&blue);
    
    if(red==0 && green == 0 && blue == 0)
    {
        cyan=magneta=yellow=0;
        black=1;
    }
    else
    {
        red=red/255;
        green=green/255;
        blue=blue/255;
        max=red;
        if(green>max)
        max=green;
        if(blue>max)
        max=blue;
        white=max;
        cyan=(white-red)/white;
        magneta=(white-green)/white;
        yellow=(white-blue)/white;
        black=1-white;
    }
    printf("CMYK%f%f%f%f\n",cyan,magneta,yellow,black);
    return 0;
}



